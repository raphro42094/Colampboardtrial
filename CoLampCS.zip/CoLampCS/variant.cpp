/*
  Copyright (c) 2020 Netcom Connected Services GmbH.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


#include "variant.h"
#include "Arduino.h"

/*
 * Pins descriptions
 */
const PinDescription g_APinDescription[] = {
/*
 +------------+------------------+--------+-----------------+--------+-----------------------+---------+---------+--------+--------+----------+----------+
 | Pin number | coLamp-OMS       |  PIN   | Notes           | Peri.A |     Peripheral B      | Perip.C | Perip.D | Peri.E | Peri.F | Periph.G | Periph.H |
 |            | Board signal     |        |                 |   EIC  | ADC |  AC | PTC | DAC | SERCOMx | SERCOMx |  TCCx  |  TCCx  |    COM   | AC/GLCK  |
 |            |                  |        |                 |(EXTINT)|(AIN)|(AIN)|     |     | (x/PAD) | (x/PAD) | (x/WO) | (x/WO) |          |          |
 +------------+------------------+--------+-----------------+--------+-----+-----+-----+-----+---------+---------+--------+--------+----------+----------+
 | 0          | RXD_MB           |  PB23  |                 |   07   |     |     |     |     |         |  *5/03  |  TC7/1 |        |          | GCLK_IO1 |
 | 1          | TXD_MB           |  PB22  |                 |   06   |     |     |     |     |         |  *5/02  |  TC7/0 |        |          | GCLK_IO0 |
 | 2          | SW_SAMD          |  PB10  | BUTTON          |  *10   |     |     |     |     |         |   4/02  |* TC5/0 | TCC0/4 | I2S/MCK1 | GCLK_IO4 |
 | 3          | LED2_SAMD        |  PB11  | LED             |  *11   |     |     |     |     |         |   4/03  |* TC5/1 | TCC0/5 | I2S/SCK1 | GCLK_IO5 |
 | 4          | RXD_WIMOD        |  PA07  |                 |   07   |  07 |  03 | Y05 |     |         |  *0/03  | TCC1/1 |        | I2S/SD0  |          |
 | 5          | RXD_GHN          |  PA05  | alt. SERCOM0/01 |   05   |  05 |  01 | Y03 |     |         |  *0/01  | TCC0/1 |        |          |          |
 | 6          | TXD_GHN          |  PA04  | alt. SERCOM0/00 |   04   |  04 |  00 | Y02 |     |         |  *0/00  | TCC0/0 |        |          |          |
 | 7          | TXD_WIMOD        |  PA06  |                 |   06   |  06 |  02 | Y04 |     |         |  *0/02  | TCC1/0 |        |          |          |
 +------------+------------------+--------+-----------------+------------------------------------------+---------+--------+------------------------------+
 | 8          | SCS_MB           |  PA18  |                 |   02   |     |     | X06 |     |  *1/02  |   3/02  |  TC3/0 | TCC0/2 |          | AC/CMP0  |
 | 9          | SWDAT_WIMOD      |  PA20  |                 |  *04   |     |     | X08 |     |   5/02  |   3/02  |  TC7/0 |*TCC0/6 |          | GCLK_IO4 |
 | 10         | SWCLK_WIMOD      |  PA21  |                 |  *05   |     |     | X09 |     |   5/03  |   3/02  |  TC7/1 |*TCC0/7 | I2S/FS0  | GCLK_IO5 |
 | 11         | MOSI_MB          |  PA16  |                 |   00   |     |     | X04 |     |  *1/00  |   3/00  | TCC2/0 | TCC0/6 |          | GCLK_IO2 |
 | 12         | MISO_MB          |  PA19  |                 |   03   |     |     | X07 |     |  *1/03  |   3/03  |  TC3/1 | TCC0/3 | I2S/SD0  | AC/CMP0  |
 | 13         | SCK_MB           |  PA17  |                 |   01   |     |     | X05 |     |  *1/01  |   3/01  | TCC2/1 | TCC0/7 |          | GCLK_IO3 |
 +------------+------------------+--------+-----------------+--------+-----+-----+-----+-----+---------+---------+--------+--------+----------+----------+
*/
  // 0,1 - SERCOM5/ UART Microbus
  { PORTB, 23, PIO_SERCOM_ALT,(PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // RXD_MB: SERCOM5/PAD[3]
  { PORTB, 22, PIO_SERCOM_ALT,(PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // TXD_MB: SERCOM5/PAD[2]
  // 2,3 - Button, LED
  { PORTB, 10, PIO_DIGITAL,   (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER    ), No_ADC_Channel, PWM5_CH0,   TC5_CH0,      EXTERNAL_INT_10   },
  { PORTB, 11, PIO_DIGITAL,   (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER    ), No_ADC_Channel, PWM5_CH1,   TC5_CH1,      EXTERNAL_INT_11   },
  // 4..7 - SERCOM0/ UARTs WIMOD- and GHN-modules
  { PORTA,  7, PIO_SERCOM_ALT,(PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // RXD_WIMOD: SERCOM0/PAD[3]
  { PORTA,  5, PIO_DIGITAL,   (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER    ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // alt. RXD_GHN: SERCOM0/PAD[1]
  { PORTA,  4, PIO_DIGITAL,   (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER    ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // alt. RXD_GHN: SERCOM0/PAD[0]
  { PORTA,  6, PIO_SERCOM_ALT,(PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // TXD_WIMOD: SERCOM0/PAD[2]
  // 8..13 - SERCOM1/ SPI Microbus and alternative function for SERCOM5/ Serial programming port WIMOD
  { PORTA, 18, PIO_SERCOM,    (PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // SCK_MB:  SERCOM1/PAD[2]
  { PORTA, 20, PIO_DIGITAL,   (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER_ALT), No_ADC_Channel, PWM0_CH6,   TCC0_CH6,     EXTERNAL_INT_4    }, // digital SWDAT_WIMOD; alt. SERCOM5/PAD[2]
  { PORTA, 21, PIO_DIGITAL,   (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER_ALT), No_ADC_Channel, PWM0_CH7,   TCC0_CH7,     EXTERNAL_INT_5    }, // digital SWCLK_WIMOD; alt. SERCOM5/PAD[3]
  { PORTA, 16, PIO_SERCOM,    (PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // MOSI_MB: SERCOM1/PAD[0]
  { PORTA, 19, PIO_SERCOM,    (PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // MISO_MB: SERCOM1/PAD[3]
  { PORTA, 17, PIO_SERCOM,    (PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // SCK_MB:  SERCOM1/PAD[1]
/*
 +------------+------------------+--------+-----------------+--------+-----------------------+---------+---------+--------+--------+----------+----------+
 | Pin number | coLamp-OMS       |  PIN   | Notes           | Peri.A |     Peripheral B      | Perip.C | Perip.D | Peri.E | Peri.F | Periph.G | Periph.H |
 |            | Board signal     |        |                 |   EIC  | ADC |  AC | PTC | DAC | SERCOMx | SERCOMx |  TCCx  |  TCCx  |    COM   | AC/GLCK  |
 |            |                  |        |                 |(EXTINT)|(AIN)|(AIN)|     |     | (x/PAD) | (x/PAD) | (x/WO) | (x/WO) |          |          |
 +------------+------------------+--------+-----------------+--------+-----+-----+-----+-----+---------+---------+--------+--------+----------+----------+
 | 14         | INT_ACC          |  PA02  |                 |  *02   |  00 |     | Y00 | OUT |         |         |        |        |          |          |
 | 15         | EN_VIN_GHN       |  PB02  |                 |   02   |  10 |     | Y08 |     |         |   5/00  |  TC6/0 |        |          |          |
 | 16         | NRES_GHN         |  PA11  |                 |   11   |  19 |     | X03 |     |   0/03  |   2/03  | TCC1/1 | TCC0/3 | I2S/FS0  | GCLK_IO5 |
 | 17         | NRES_MB          |  PA10  |                 |   10   |  18 |     | X02 |     |   0/02  |   2/02  | TCC1/0 | TCC0/2 | I2S/SCK0 | GCLK_IO4 |
 | 18         | I2C_SDA_SAMD     |  PB08  | SDA             |   08   |  02 |     | Y14 |     |         |  *4/00  |  TC4/0 |        |          |          |
 | 19         | I2C_SCL_SAMD     |  PB09  | SCL             |  *09   |  03 |     | Y15 |     |         |  *4/01  |* TC4/1 |        |          |          |
 | 20         | NRES_WIMOD       |  PA09  |                 |   09   |  17 |     | X01 |     |   0/01  |   2/01  | TCC0/1 | TCC1/3 | I2S/MCK0 |          |
 | 21         | BOOT_WIMOD       |  PB03  |                 |  *03   |  11 |     | Y09 |     |         |   5/01  |  TC6/1 |        |          |          |
 +------------+------------------+--------+-----------------+--------+-----+-----+-----+-----+---------+---------+--------+--------+----------+----------+
*/
  // 14..17 - digital
  { PORTA,  2, PIO_DIGITAL, (PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_2    }, // INT_ACC
  { PORTB,  2, PIO_DIGITAL, (PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // EN_VIN_GHN
  { PORTA, 11, PIO_DIGITAL, (PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // NRES_GHN
  { PORTA, 10, PIO_DIGITAL, (PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // NRES_MB
  // 18,19 - SERCOM4/ I2C
  { PORTB,  8, PIO_SERCOM_ALT, (PIN_ATTR_DIGITAL                             ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // SDA: SERCOM4/PAD[0]
  { PORTB,  9, PIO_SERCOM_ALT, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER ), No_ADC_Channel, PWM4_CH1,   TC4_CH1,      EXTERNAL_INT_9    }, // SCL: SERCOM4/PAD[1]
  // 20,21 - digital
  { PORTA,  9, PIO_DIGITAL,  (PIN_ATTR_DIGITAL                               ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // NRES_WIMOD
  { PORTB,  3, PIO_DIGITAL,  (PIN_ATTR_DIGITAL                               ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // BOOT_WIMOD
/*
 +------------+------------------+--------+-----------------+--------+-----------------------+---------+---------+--------+--------+----------+----------+
 | Pin number | coLamp-OMS       |  PIN   | Notes           | Peri.A |     Peripheral B      | Perip.C | Perip.D | Peri.E | Peri.F | Periph.G | Periph.H |
 |            | Board signal     |        |                 |   EIC  | ADC |  AC | PTC | DAC | SERCOMx | SERCOMx |  TCCx  |  TCCx  |    COM   | AC/GLCK  |
 |            |                  |        |                 |(EXTINT)|(AIN)|(AIN)|     |     | (x/PAD) | (x/PAD) | (x/WO) | (x/WO) |          |          |
 +------------+------------------+--------+-----------------+--------+-----+-----+-----+-----+---------+---------+--------+--------+----------+----------+
 | 22         | V_MISO_NINA      |  PA12  | NINA_MOSI       |   12   |     |     |     |     |  *2/00  |   4/00  | TCC2/0 | TCC0/6 |          | AC/CMP0  |
 | 23         | V_MOSI_NINA      |  PA13  | NINA_MISO       |   13   |     |     |     |     |  *2/01  |   4/01  | TCC2/1 | TCC0/7 |          | AC/CMP1  |
 | 24         | V_RTS_NINA       |  PA14  | NINA_RTS        |   14   |     |     |     |     |   2/02  |   4/02  |  TC3/0 | TCC0/4 |          | GCLK_IO0 |
 | 25         | V_CTS_NINA       |  PA15  | NINA_CTS        |   15   |     |     |     |     |  *2/03  |   4/03  |  TC3/1 | TCC0/5 |          | GCLK_IO1 |
 | 26         | BOOT_NINA        |  PA27  | NINA_GPIO0      |  *15   |     |     |     |     |         |         |        |        |          | GCLK_IO0 |
 | 27         | NRES_NINA        |  PA08  | NINA_RESETN     |   NMI  |  16 |     | X00 |     |   0/00  |   2/00  | TCC0/0 | TCC1/2 | I2S/SD1  |          |
 | 28         | ACK_NINA         |  PA28  | NINA_GPIO7      |   08   |     |     |     |     |         |         |        |        |          | GCLK_IO0 |
 +------------+------------------+--------+-----------------+--------+-----+-----+-----+-----+---------+---------+--------+--------+----------+----------+
*/
 // 22..25 - SERCOM2/ SPI NINA
//  { PORTA, 12, PIO_SERCOM, (PIN_ATTR_NONE                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // V_MISO_NINA: SERCOM2/PAD[0]
  { PORTA, 12, PIO_DIGITAL, (PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // V_MISO_NINA: SERCOM2/PAD[0]
  { PORTA, 13, PIO_SERCOM, (PIN_ATTR_NONE                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // V_MOSO_NINA: SERCOM2/PAD[1]
  { PORTA, 14, PIO_SERCOM, (PIN_ATTR_NONE                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // V_RTS_NINA:  SERCOM2/PAD[2]
//  { PORTA, 15, PIO_SERCOM, (PIN_ATTR_NONE                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // V_CTS_NINA:  SERCOM2/PAD[3]
  { PORTA, 15, PIO_DIGITAL, (PIN_ATTR_DIGITAL                                ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // V_CTS_NINA:  SERCOM2/PAD[3]
  // 26..28 - digital
  { PORTA, 27, PIO_DIGITAL,(PIN_ATTR_DIGITAL                             ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // BOOT_NINA
  { PORTA,  8, PIO_DIGITAL,(PIN_ATTR_DIGITAL                             ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // NRES_NINA
  { PORTA, 28, PIO_DIGITAL,(PIN_ATTR_DIGITAL                             ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // ACK_NINA
/*
 +------------+------------------+--------+-----------------+--------+-----------------------+---------+---------+--------+--------+----------+----------+
 | Pin number | coLamp-OMS       |  PIN   | Notes           | Peri.A |     Peripheral B      | Perip.C | Perip.D | Peri.E | Peri.F | Periph.G | Periph.H |
 |            | Board signal     |        |                 |   EIC  | ADC |  AC | PTC | DAC | SERCOMx | SERCOMx |  TCCx  |  TCCx  |    COM   | AC/GLCK  |
 |            |                  |        |                 |(EXTINT)|(AIN)|(AIN)|     |     | (x/PAD) | (x/PAD) | (x/WO) | (x/WO) |          |          |
 +------------+------------------+--------+-----------------+--------+-----+-----+-----+-----+---------+---------+--------+--------+----------+----------+
 | 29         | TXD_NINA         |  PA22  | NINA_RXD        |   06   |     |     | X10 |     |   3/00  |   5/00  |  TC4/0 | TCC0/4 |          | GCLK_IO6 |
 | 30         | RXD_NINA         |  PA23  | NINA_TXD        |   07   |     |     | X11 |     |   3/01  |   5/01  |  TC4/1 | TCC0/5 | USB/SOF  | GCLK_IO7 |
 | 31         | USB_N            |  PA24  |                 |   12   |     |     |     |     |   3/02  |   5/02  |  TC5/0 | TCC1/2 | USB/DM   |          |
 | 32         | USB_P            |  PA25  |                 |   13   |     |     |     |     |   3/03  |   5/03  |  TC5/1 | TCC1/3 | USB/DP   |          |
 +------------+------------------+--------+-----------------+--------+-----+-----+-----+-----+---------+---------+--------+--------+----------+----------+
*/
  // 29,30 - SERCOM3/ UART NINA
  { PORTA, 22, PIO_SERCOM, (PIN_ATTR_DIGITAL                             ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  { PORTA, 23, PIO_SERCOM, (PIN_ATTR_DIGITAL                             ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },
  // 31,32 - USB
  { PORTA, 24, PIO_COM,   (PIN_ATTR_NONE                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // USB/DM
  { PORTA, 25, PIO_COM,   (PIN_ATTR_NONE                                 ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // USB/DP
/*
 +------------+------------------+--------+-----------------+--------+-----------------------+---------+---------+--------+--------+----------+----------+
 | Pin number | coLamp-OMS       |  PIN   | Notes           | Peri.A |     Peripheral B      | Perip.C | Perip.D | Peri.E | Peri.F | Periph.G | Periph.H |
 |            | Board signal     |        |                 |   EIC  | ADC |  AC | PTC | DAC | SERCOMx | SERCOMx |  TCCx  |  TCCx  |    COM   | AC/GLCK  |
 |            |                  |        |                 |(EXTINT)|(AIN)|(AIN)|     |     | (x/PAD) | (x/PAD) | (x/WO) | (x/WO) |          |          |
 +------------+------------------+--------+-----------------+--------+-----+-----+-----+-----+---------+---------+--------+--------+----------+----------+
 | 33         | INT_MB           |  PA03  |                 |  *03   |  01 |     | Y01 |     |         |         |        |        |          |          |
 | 34         | SAMD_SWCLK       |  PA30  |                 |   10   |     |     |     |     |         |   1/00  |        |        |   SWCLK  |          |
 | 35         | SAMD_SWDIO       |  PA31  |                 |   11   |     |     |     |     |         |   1/03  |        |        |   SWDIO  |          |
 +------------+------------------+--------+-----------------+--------+-----+-----+-----+-----+---------+---------+--------+--------+----------+----------+
 */
  // 33 - digital
  { PORTA,  3, PIO_DIGITAL, (PIN_ATTR_DIGITAL                            ), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_3    }, // INT_MB
} ;

extern "C" {
    unsigned int PINCOUNT_fn() {
        return (sizeof(g_APinDescription) / sizeof(g_APinDescription[0]));
    }
}

const void* g_apTCInstances[TCC_INST_NUM+TC_INST_NUM]={ TCC0, TCC1, TCC2, TC3, TC4, TC5 } ;

void initVariant() {
  // NINA
  // SPI boot - disable
//  pinMode(BOOT_NINA, OUTPUT);
//  digitalWrite(BOOTNINA, HIGH);
  // reset module - enable
  pinMode(NRES_NINA, OUTPUT);
  digitalWrite(NRES_NINA, LOW);

  // GHN
  // power GHN - disable
  pinMode(EN_VIN_GHN, OUTPUT);
  digitalWrite(EN_VIN_GHN, LOW);
  // reset module - enable
  pinMode(NRES_GHN, OUTPUT);
  digitalWrite(NRES_GHN, LOW);
 
  // WIMOD
  // reset module - disable
  pinMode(NRES_WIMOD, OUTPUT);
  digitalWrite(NRES_WIMOD, HIGH);
}

// Multi-serial objects instantiation
SERCOM sercom0( SERCOM0 ) ; // UART WIMOD (RXD_WIMOD, TXD_WIMOD) with alternative function: UART GHN (RXD_GHN, TXD_GHN)
SERCOM sercom1( SERCOM1 ) ; // SPI Microbus (MOSI_MB, MISO_MB)
SERCOM sercom2( SERCOM2 ) ; // SPI NINA
SERCOM sercom3( SERCOM3 ) ; // UART NINA
SERCOM sercom4( SERCOM4 ) ; // I2C (I2C_SDA_DAMD, I2C_SCL_SAMD)
SERCOM sercom5( SERCOM5 ) ; // UART MicroBus (RXD_MB, TXD_MB)

/*Uart SerialHCI(&sercom2, V_MOSI_NINA, V_MISO_NINA, PAD_SERIALHCI_RX, PAD_SERIALHCI_TX, V_RTS_NINA, V_CTS_NINA);

void SERCOM2_Handler()
{
  SerialHCI.IrqHandler();
}*/

Uart Serial1( &sercom5, RXD_MB, TXD_MB, PAD_SERIAL1_RX, PAD_SERIAL1_TX ) ;

void SERCOM5_Handler()
{
  Serial1.IrqHandler();
}

Uart Serial2(&sercom3, RXD_NINA, TXD_NINA, PAD_SERIAL2_RX, PAD_SERIAL2_TX);

void SERCOM3_Handler()
{
  Serial2.IrqHandler();
}

Uart Serial3(&sercom0, RXD_WIMOD, TXD_WIMOD, PAD_SERIAL3_RX, PAD_SERIAL3_TX);

void SERCOM0_Handler()
{
  Serial3.IrqHandler();
}
